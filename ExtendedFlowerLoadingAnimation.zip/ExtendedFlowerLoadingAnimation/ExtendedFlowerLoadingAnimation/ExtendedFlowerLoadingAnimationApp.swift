//

import SwiftUI

@main
struct ExtendedFlowerLoadingAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
